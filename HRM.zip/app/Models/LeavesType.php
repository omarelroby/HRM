<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LeavesType extends Model
{
    protected $table = 'leaves_types';
    protected $guarded = [];
}
