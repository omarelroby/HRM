<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class FCMToken
 * @package App\Models
 */
class FCMToken extends Model
{
    protected $table = 'fcm';
    protected $guarded = [];
}
