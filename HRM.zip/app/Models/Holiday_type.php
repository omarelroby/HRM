<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Holiday_type extends Model
{
    protected $fillable = [
        'name','name_ar','created_by'
    ];
}
